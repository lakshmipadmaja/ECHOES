/* =========================================================
   ECHOES — COMPLETE FRONTEND APP
   Category Input + Story + Language + Voice
   ========================================================= */

const state = {
    language: "en",
    moments: {},
    currentCategory: null,
    currentStory: ""
};


/* =========================================================
   CATEGORY INFORMATION
   ========================================================= */

const CATEGORY_INFO = {

    receipts: {
        icon: "🧾",
        title: "Receipts",
        question: "What did you purchase?"
    },

    music: {
        icon: "🎵",
        title: "Music",
        question: "What were you listening to?"
    },

    books: {
        icon: "📚",
        title: "Books",
        question: "What were you reading?"
    },

    places: {
        icon: "📍",
        title: "Places",
        question: "Where did you go?"
    },

    photos: {
        icon: "📸",
        title: "Photos",
        question: "What does this photo remember?"
    },

    movie: {
        icon: "🎬",
        title: "Movie",
        question: "What movie did you watch?"
    },

    events: {
        icon: "🎉",
        title: "Events",
        question: "What event did you attend?"
    },

    food: {
        icon: "🍔",
        title: "Food",
        question: "What did you eat or drink?"
    }
};


/* =========================================================
   LANGUAGE TEXT
   ========================================================= */

const LANGUAGE_TEXT = {

    en: {
        save: "Save This Moment",
        input: "Tell us about this moment",
        placeholder:
            "What happened? What did you do, see, hear, eat, buy or experience?",
        saved: "Moment saved successfully.",
        listen: "🔊 Listen",
        speaking: "🔊 Speaking...",
        stop: "⏹ Stop"
    },

    te: {
        save: "ఈ Moment Save చేయి",
        input: "ఈ moment గురించి చెప్పండి",
        placeholder:
            "ఏం జరిగింది? ఏం చేశారు, చూశారు, విన్నారు, తిన్నారు లేదా కొనుగోలు చేశారు?",
        saved: "Moment విజయవంతంగా save అయింది.",
        listen: "🔊 వినండి",
        speaking: "🔊 వింటున్నారు...",
        stop: "⏹ ఆపండి"
    },

    hi: {
        save: "इस Moment को Save करें",
        input: "इस moment के बारे में बताएं",
        placeholder:
            "क्या हुआ? आपने क्या किया, देखा, सुना, खाया या खरीदा?",
        saved: "Moment सफलतापूर्वक save हो गया।",
        listen: "🔊 सुनें",
        speaking: "🔊 बोल रहा है...",
        stop: "⏹ रोकें"
    },

    ta: {
        save: "இந்த Moment-ஐ Save செய்",
        input: "இந்த moment பற்றி சொல்லுங்கள்",
        placeholder:
            "என்ன நடந்தது? என்ன செய்தீர்கள், பார்த்தீர்கள் அல்லது சாப்பிட்டீர்கள்?",
        saved: "Moment save செய்யப்பட்டது.",
        listen: "🔊 கேட்க",
        speaking: "🔊 பேசுகிறது...",
        stop: "⏹ நிறுத்து"
    },

    kn: {
        save: "ಈ Moment Save ಮಾಡಿ",
        input: "ಈ moment ಬಗ್ಗೆ ಹೇಳಿ",
        placeholder:
            "ಏನಾಯಿತು? ನೀವು ಏನು ಮಾಡಿದರು, ನೋಡಿದರು, ಕೇಳಿದರು ಅಥವಾ ತಿಂದಿರಿ?",
        saved: "Moment save ಆಯಿತು.",
        listen: "🔊 ಕೇಳಿ",
        speaking: "🔊 ಮಾತನಾಡುತ್ತಿದೆ...",
        stop: "⏹ ನಿಲ್ಲಿಸಿ"
    },

    ml: {
        save: "ഈ Moment Save ചെയ്യുക",
        input: "ഈ moment കുറിച്ച് പറയൂ",
        placeholder:
            "എന്താണ് സംഭവിച്ചത്? നിങ്ങൾ എന്ത് ചെയ്തു, കണ്ടു, കേട്ടു അല്ലെങ്കിൽ കഴിച്ചു?",
        saved: "Moment save ചെയ്തു.",
        listen: "🔊 കേൾക്കുക",
        speaking: "🔊 സംസാരിക്കുന്നു...",
        stop: "⏹ നിർത്തുക"
    }
};


/* =========================================================
   LANGUAGE SELECTOR
   ========================================================= */

function setupLanguage() {

    const selector =
        document.getElementById("languageSelect") ||
        document.getElementById("languageSelector") ||
        document.getElementById("languageSwitcher") ||
        document.querySelector("select");

    if (!selector) {
        console.log("Language selector not found.");
        return;
    }

    state.language =
        selector.value || "en";

    selector.addEventListener(
        "change",
        function () {

            state.language =
                selector.value || "en";

            console.log(
                "Language changed:",
                state.language
            );
        }
    );
}


/* =========================================================
   CREATE INPUT MODAL
   ========================================================= */

function createMomentModal() {

    let modal =
        document.getElementById(
            "echoMomentModal"
        );

    if (modal) {
        return modal;
    }


    modal =
        document.createElement("div");

    modal.id =
        "echoMomentModal";


    modal.innerHTML = `

        <div class="echo-modal-backdrop"></div>

        <div class="echo-modal-box">

            <button
                id="echoModalClose"
                class="echo-modal-close"
                type="button">
                ×
            </button>

            <div
                id="echoModalIcon"
                class="echo-modal-icon">
                ✨
            </div>

            <div
                id="echoModalTitle"
                class="echo-modal-title">
                Add Moment
            </div>

            <div
                id="echoModalQuestion"
                class="echo-modal-question">
                Tell us about this moment.
            </div>


            <div class="echo-date-grid">

                <div>

                    <label>
                        Date
                    </label>

                    <input
                        id="echoDate"
                        type="date">

                </div>


                <div>

                    <label>
                        Time
                    </label>

                    <input
                        id="echoTime"
                        type="time">

                </div>

            </div>


            <label
                id="echoInputLabel">
                Tell us about this moment
            </label>


            <textarea
                id="echoMomentInput"
                rows="6"
                placeholder="What happened?">
            </textarea>


            <button
                id="echoSaveMoment"
                class="echo-save-button"
                type="button">
                Save This Moment
            </button>


            <div
                id="echoSavedMessage"
                class="echo-saved-message">
            </div>

        </div>
    `;


    document.body.appendChild(modal);


    document
        .getElementById("echoModalClose")
        .addEventListener(
            "click",
            closeMomentModal
        );


    document
        .querySelector(
            ".echo-modal-backdrop"
        )
        .addEventListener(
            "click",
            closeMomentModal
        );


    document
        .getElementById("echoSaveMoment")
        .addEventListener(
            "click",
            saveCurrentMoment
        );


    return modal;
}


/* =========================================================
   OPEN CATEGORY
   ========================================================= */

function openCategory(category) {

    console.log(
        "CATEGORY CLICKED:",
        category
    );


    if (!CATEGORY_INFO[category]) {

        console.log(
            "Unknown category:",
            category
        );

        return;
    }


    state.currentCategory =
        category;


    const modal =
        createMomentModal();


    const info =
        CATEGORY_INFO[category];


    const language =
        LANGUAGE_TEXT[
            state.language
        ] || LANGUAGE_TEXT.en;


    document
        .getElementById(
            "echoModalIcon"
        )
        .textContent =
        info.icon;


    document
        .getElementById(
            "echoModalTitle"
        )
        .textContent =
        info.title;


    document
        .getElementById(
            "echoModalQuestion"
        )
        .textContent =
        info.question;


    document
        .getElementById(
            "echoInputLabel"
        )
        .textContent =
        language.input;


    document
        .getElementById(
            "echoMomentInput"
        )
        .placeholder =
        language.placeholder;


    document
        .getElementById(
            "echoSaveMoment"
        )
        .textContent =
        language.save;


    const existing =
        state.moments[category];


    if (existing) {

        document
            .getElementById(
                "echoDate"
            )
            .value =
            existing.date;


        document
            .getElementById(
                "echoTime"
            )
            .value =
            existing.time;


        document
            .getElementById(
                "echoMomentInput"
            )
            .value =
            existing.text;

    } else {

        const now =
            new Date();


        const date =
            now
                .toISOString()
                .split("T")[0];


        const time =
            now
                .toTimeString()
                .slice(0, 5);


        document
            .getElementById(
                "echoDate"
            )
            .value =
            date;


        document
            .getElementById(
                "echoTime"
            )
            .value =
            time;


        document
            .getElementById(
                "echoMomentInput"
            )
            .value =
            "";
    }


    document
        .getElementById(
            "echoSavedMessage"
        )
        .textContent =
        "";


    modal.classList.add(
        "show"
    );
}


/* =========================================================
   SAVE MOMENT
   ========================================================= */

function saveCurrentMoment() {

    const category =
        state.currentCategory;


    const date =
        document
            .getElementById(
                "echoDate"
            )
            .value;


    const time =
        document
            .getElementById(
                "echoTime"
            )
            .value;


    const text =
        document
            .getElementById(
                "echoMomentInput"
            )
            .value
            .trim();


    if (!text) {

        document
            .getElementById(
                "echoSavedMessage"
            )
            .innerHTML =

            `<span style="color:#ff7f96;">
                Please enter something about this moment.
            </span>`;

        return;
    }


    state.moments[category] = {

        category:
            category,

        date:
            date,

        time:
            time,

        text:
            text
    };


    console.log(
        "MOMENT SAVED:",
        state.moments[category]
    );


    const language =
        LANGUAGE_TEXT[
            state.language
        ] || LANGUAGE_TEXT.en;


    document
        .getElementById(
            "echoSavedMessage"
        )
        .innerHTML =

        `<span style="color:#72ffb0;">
            ✓ ${language.saved}
        </span>`;


    setTimeout(
        closeMomentModal,
        700
    );
}


/* =========================================================
   CLOSE MODAL
   ========================================================= */

function closeMomentModal() {

    const modal =
        document.getElementById(
            "echoMomentModal"
        );


    if (modal) {

        modal.classList.remove(
            "show"
        );
    }
}


/* =========================================================
   CATEGORY CLICK SYSTEM
   ========================================================= */

function setupCategories() {

    document.addEventListener(
        "click",
        function (event) {

            const card =
                event.target.closest(
                    ".category-card"
                );


            if (!card) {
                return;
            }


            const category =
                card.getAttribute(
                    "data-category"
                );


            if (!category) {
                return;
            }


            event.preventDefault();

            event.stopPropagation();


            openCategory(
                category
            );
        },
        true
    );


    document
        .querySelectorAll(
            ".category-card"
        )
        .forEach(
            card => {

                card.style.cursor =
                    "pointer";

                card.style.pointerEvents =
                    "auto";

                card.style.position =
                    "relative";

                card.style.zIndex =
                    "50";
            }
        );


    console.log(
        "CATEGORY SYSTEM READY"
    );
}


/* =========================================================
   GENERATE ECHOES BUTTON
   ========================================================= */

function setupGenerateButton() {

    const button =
        document.getElementById(
            "generateEchoesBtn"
        );


    if (!button) {

        console.log(
            "Generate button not found."
        );

        return;
    }


    button.addEventListener(
        "click",
        generateEchoes
    );
}


/* =========================================================
   GENERATE ECHOES
   ========================================================= */

function generateEchoes() {

    console.log(
        "GENERATING ECHOES:",
        state.moments
    );


    const moments =
        Object.values(
            state.moments
        );


    if (!moments.length) {

        showNoMomentMessage();

        return;
    }


    showProcessing();


    setTimeout(
        function () {

            const story =
                createStory(
                    moments
                );


            state.currentStory =
                story;


            hideProcessing();


            showStory(
                story
            );

        },
        900
    );
}


/* =========================================================
   NO MOMENT
   ========================================================= */

function showNoMomentMessage() {

    const button =
        document.getElementById(
            "generateEchoesBtn"
        );


    if (!button) {
        return;
    }


    const oldText =
        button.textContent;


    button.textContent =
        "✨ Add a moment first";


    setTimeout(
        function () {

            button.textContent =
                oldText ||
                "Generate My Echoes";

        },
        2000
    );
}


/* =========================================================
   CREATE STORY
   ========================================================= */

function createStory(moments) {

    moments.sort(
        function (a, b) {

            const first =
                new Date(
                    `${a.date}T${a.time}`
                );


            const second =
                new Date(
                    `${b.date}T${b.time}`
                );


            return first - second;
        }
    );


    const first =
        moments[0];


    const date =
        new Date(
            `${first.date}T00:00:00`
        );


    const formattedDate =
        date.toLocaleDateString(
            "en-IN",
            {
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );


    let story = "";


    story +=
        `On ${formattedDate}, your day unfolded through a series of meaningful moments. `;


    story +=
        `What began as individual memories slowly became a connected story. `;


    moments.forEach(
        function (moment) {

            const info =
                CATEGORY_INFO[
                    moment.category
                ];


            const time =
                formatTime(
                    moment.time
                );


            story +=
                `At ${time}, your ${info.title.toLowerCase()} moment was "${moment.text}". `;
        }
    );


    if (moments.length >= 2) {

        const names =
            moments.map(
                function (moment) {

                    return CATEGORY_INFO[
                        moment.category
                    ].title;
                }
            );


        story +=
            `Together, ${names.join(", ")} were not separate events. `;


        story +=
            `They formed a sequence that captured how your day moved from one experience to another. `;
    }


    if (moments.length >= 4) {

        story +=
            `The time, choices and experiences create a richer picture of the person behind these moments. `;


        story +=
            `This is where the individual memories become your Echoes — a connected reflection of what you did, where you were, what you enjoyed and what mattered during that day. `;
    }


    story +=
        `Looking back, this day is more than a list of activities. `;


    story +=
        `It is a personal story built from the moments you chose to remember.`;


    return story;
}


/* =========================================================
   FORMAT TIME
   ========================================================= */

function formatTime(time) {

    if (!time) {
        return "";
    }


    const parts =
        time.split(":");


    let hour =
        Number(
            parts[0]
        );


    const minute =
        parts[1] || "00";


    const suffix =
        hour >= 12
            ? "PM"
            : "AM";


    hour =
        hour % 12 || 12;


    return `${hour}:${minute} ${suffix}`;
}


/* =========================================================
   SHOW STORY
   ========================================================= */

function showStory(story) {

    const section =
        document.getElementById(
            "storySection"
        );


    if (section) {

        section.hidden =
            false;


        const content =
            document.getElementById(
                "storyContent"
            );


        if (content) {

            content.textContent =
                story;
        }


        const title =
            document.getElementById(
                "storyTitle"
            );


        if (title) {

            title.textContent =
                "Your Day, Reconstructed";
        }


        const meta =
            document.getElementById(
                "storyMeta"
            );


        if (meta) {

            meta.textContent =
                `${Object.keys(
                    state.moments
                ).length} moments connected`;
        }


        addVoiceButtons();


        section.scrollIntoView({
            behavior: "smooth"
        });


        return;
    }


    /*
       Fallback story section
    */

    const generated =
        document.createElement(
            "section"
        );


    generated.id =
        "echoGeneratedStory";


    generated.innerHTML = `

        <div class="echo-story-box">

            <div class="echo-story-kicker">
                YOUR ECHOES
            </div>

            <h2>
                Your Day, Reconstructed
            </h2>

            <div class="echo-story-meta">
                ${Object.keys(state.moments).length}
                moments connected
            </div>

            <p id="echoFinalStory">
                ${escapeHTML(story)}
            </p>

            <div class="echo-story-actions">

                <button
                    id="echoListenButton"
                    type="button">
                    🔊 Listen
                </button>

                <button
                    id="echoStopButton"
                    type="button">
                    ⏹ Stop
                </button>

            </div>

        </div>
    `;


    const main =
        document.querySelector(
            "main"
        );


    if (main) {

        main.appendChild(
            generated
        );

    } else {

        document.body.appendChild(
            generated
        );
    }


    document
        .getElementById(
            "echoListenButton"
        )
        .addEventListener(
            "click",
            function () {

                startEchoVoice(
                    state.currentStory
                );
            }
        );


    document
        .getElementById(
            "echoStopButton"
        )
        .addEventListener(
            "click",
            stopEchoVoice
        );


    generated.scrollIntoView({
        behavior: "smooth"
    });
}


/* =========================================================
   VOICE BUTTON CONNECTION
   ========================================================= */

function addVoiceButtons() {

    const listen =
        document.getElementById(
            "listenStoryBtn"
        );


    const stop =
        document.getElementById(
            "stopStoryBtn"
        );


    if (listen) {

        listen.onclick =
            function () {

                startEchoVoice(
                    state.currentStory
                );
            };
    }


    if (stop) {

        stop.onclick =
            function () {

                stopEchoVoice();
            };
    }
}


/* =========================================================
   VOICE ENGINE
   ========================================================= */

let echoSpeechChunks = [];

let echoCurrentChunk = 0;

let echoIsSpeaking = false;


/* =========================================================
   START VOICE
   ========================================================= */

function startEchoVoice(text) {

    if (!text || !text.trim()) {

        console.log(
            "No story available."
        );

        return;
    }


    if (!("speechSynthesis" in window)) {

        alert(
            "Voice is not supported in this browser. Please use Google Chrome."
        );

        return;
    }


    /*
       Stop old speech
    */

    window.speechSynthesis.cancel();


    /*
       Split story into short sentences.
       This makes Chrome voice much more reliable.
    */

    echoSpeechChunks =
        splitStoryIntoChunks(
            text
        );


    echoCurrentChunk =
        0;


    echoIsSpeaking =
        true;


    speakNextChunk();
}


/* =========================================================
   SPLIT STORY INTO CHUNKS
   ========================================================= */

function splitStoryIntoChunks(text) {

    const sentences =
        text.match(
            /[^.!?]+[.!?]+/g
        );


    if (!sentences) {

        return [text];
    }


    return sentences;
}


/* =========================================================
   SPEAK NEXT CHUNK
   ========================================================= */

function speakNextChunk() {

    if (!echoIsSpeaking) {
        return;
    }


    if (
        echoCurrentChunk >=
        echoSpeechChunks.length
    ) {

        finishEchoVoice();

        return;
    }


    const text =
        echoSpeechChunks[
            echoCurrentChunk
        ];


    const speech =
        new SpeechSynthesisUtterance(
            text
        );


    /*
       Language
    */

    const language =
        state.language || "en";


    const languageMap = {

        en: "en-IN",

        te: "te-IN",

        hi: "hi-IN",

        ta: "ta-IN",

        kn: "kn-IN",

        ml: "ml-IN"
    };


    speech.lang =
        languageMap[language] ||
        "en-IN";


    speech.rate =
        0.9;


    speech.pitch =
        1;


    speech.volume =
        1;


    /*
       Find matching browser voice
    */

    const voices =
        window.speechSynthesis
            .getVoices();


    const shortLanguage =
        speech.lang
            .split("-")[0]
            .toLowerCase();


    const matchingVoice =
        voices.find(
            function (voice) {

                return voice.lang
                    .toLowerCase()
                    .startsWith(
                        shortLanguage
                    );
            }
        );


    if (matchingVoice) {

        speech.voice =
            matchingVoice;


        console.log(
            "Using voice:",
            matchingVoice.name,
            matchingVoice.lang
        );

    } else {

        console.log(
            "Using browser default voice."
        );
    }


    /*
       Start
    */

    speech.onstart =
        function () {

            console.log(
                "🔊 ECHOES voice started"
            );


            const button =
                document.getElementById(
                    "listenStoryBtn"
                );


            if (button) {

                const language =
                    LANGUAGE_TEXT[
                        state.language
                    ] || LANGUAGE_TEXT.en;


                button.textContent =
                    language.speaking;
            }
        };


    /*
       Next sentence
    */

    speech.onend =
        function () {

            echoCurrentChunk++;


            setTimeout(
                function () {

                    speakNextChunk();

                },
                100
            );
        };


    /*
       Error
    */

    speech.onerror =
        function (event) {

            console.log(
                "Speech error:",
                event.error
            );


            if (
                event.error ===
                "interrupted"
            ) {

                return;
            }


            echoCurrentChunk++;


            setTimeout(
                function () {

                    speakNextChunk();

                },
                100
            );
        };


    /*
       Chrome speech resume
    */

    window.speechSynthesis.resume();


    /*
       Speak
    */

    window.speechSynthesis.speak(
        speech
    );
}


/* =========================================================
   STOP VOICE
   ========================================================= */

function stopEchoVoice() {

    echoIsSpeaking =
        false;


    echoSpeechChunks =
        [];


    echoCurrentChunk =
        0;


    if (
        "speechSynthesis" in window
    ) {

        window.speechSynthesis.cancel();

        window.speechSynthesis.resume();
    }


    const button =
        document.getElementById(
            "listenStoryBtn"
        );


    if (button) {

        const language =
            LANGUAGE_TEXT[
                state.language
            ] || LANGUAGE_TEXT.en;


        button.textContent =
            language.listen;
    }


    console.log(
        "⏹ ECHOES voice stopped"
    );
}


/* =========================================================
   VOICE FINISHED
   ========================================================= */

function finishEchoVoice() {

    echoIsSpeaking =
        false;


    echoCurrentChunk =
        0;


    const button =
        document.getElementById(
            "listenStoryBtn"
        );


    if (button) {

        const language =
            LANGUAGE_TEXT[
                state.language
            ] || LANGUAGE_TEXT.en;


        button.textContent =
            language.listen;
    }


    console.log(
        "✅ ECHOES voice finished"
    );
}


/* =========================================================
   LOAD BROWSER VOICES
   ========================================================= */

if (
    "speechSynthesis" in window
) {

    window.speechSynthesis
        .onvoiceschanged =
        function () {

            const voices =
                window.speechSynthesis
                    .getVoices();


            console.log(
                "Available voices:",
                voices.length
            );
        };
}


/* =========================================================
   PROCESSING OVERLAY
   ========================================================= */

function showProcessing() {

    const overlay =
        document.getElementById(
            "analysisOverlay"
        );


    if (overlay) {

        overlay.hidden =
            false;


        overlay.style.display =
            "flex";
    }
}


function hideProcessing() {

    const overlay =
        document.getElementById(
            "analysisOverlay"
        );


    if (overlay) {

        overlay.hidden =
            true;


        overlay.style.display =
            "none";
    }
}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHTML(text) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        text;


    return div.innerHTML;
}


/* =========================================================
   MODAL + STORY STYLES
   ========================================================= */

function addModalStyles() {

    if (
        document.getElementById(
            "echoModalStyles"
        )
    ) {
        return;
    }


    const style =
        document.createElement(
            "style"
        );


    style.id =
        "echoModalStyles";


    style.textContent = `

        #echoMomentModal {

            position: fixed;

            inset: 0;

            z-index: 999999;

            display: none;

            align-items: center;

            justify-content: center;

            padding: 20px;

            box-sizing: border-box;
        }


        #echoMomentModal.show {

            display: flex;
        }


        .echo-modal-backdrop {

            position: absolute;

            inset: 0;

            background:
                rgba(2,4,18,.84);

            backdrop-filter:
                blur(14px);
        }


        .echo-modal-box {

            position: relative;

            width:
                min(560px, 94vw);

            max-height: 90vh;

            overflow-y: auto;

            padding: 28px;

            border-radius: 24px;

            background:
                linear-gradient(
                    145deg,
                    rgba(24,27,55,.98),
                    rgba(7,9,25,.98)
                );

            border:
                1px solid
                rgba(150,130,255,.35);

            box-shadow:
                0 30px 100px
                rgba(0,0,0,.7),

                0 0 60px
                rgba(100,80,255,.18);

            color: white;

            z-index: 2;
        }


        .echo-modal-close {

            position: absolute;

            top: 12px;

            right: 14px;

            width: 34px;

            height: 34px;

            border-radius: 50%;

            border:
                1px solid
                rgba(255,255,255,.15);

            background:
                rgba(255,255,255,.08);

            color: white;

            font-size: 24px;

            cursor: pointer;
        }


        .echo-modal-icon {

            font-size: 38px;

            margin-bottom: 8px;
        }


        .echo-modal-title {

            font-size: 28px;

            font-weight: 800;

            margin-bottom: 6px;
        }


        .echo-modal-question {

            opacity: .7;

            margin-bottom: 22px;
        }


        .echo-date-grid {

            display: grid;

            grid-template-columns:
                1fr 1fr;

            gap: 14px;

            margin-bottom: 18px;
        }


        .echo-modal-box label {

            display: block;

            font-size: 12px;

            opacity: .65;

            margin-bottom: 7px;
        }


        .echo-modal-box input,

        .echo-modal-box textarea {

            width: 100%;

            box-sizing: border-box;

            padding: 13px;

            border-radius: 12px;

            border:
                1px solid
                rgba(255,255,255,.14);

            background:
                rgba(0,0,0,.3);

            color: white;

            outline: none;

            font-family: inherit;
        }


        .echo-modal-box textarea {

            resize: vertical;

            min-height: 130px;

            margin-bottom: 15px;
        }


        .echo-save-button {

            width: 100%;

            padding: 14px;

            border: 0;

            border-radius: 13px;

            background:
                linear-gradient(
                    135deg,
                    #7c5cff,
                    #3b82f6
                );

            color: white;

            font-weight: 800;

            cursor: pointer;
        }


        .echo-saved-message {

            margin-top: 10px;

            text-align: center;

            min-height: 20px;

            font-size: 13px;
        }


        .echo-story-box {

            max-width: 900px;

            margin: 70px auto;

            padding: 35px;

            border-radius: 25px;

            background:
                rgba(12,15,35,.82);

            border:
                1px solid
                rgba(140,120,255,.25);

            box-shadow:
                0 25px 80px
                rgba(0,0,0,.45);
        }


        .echo-story-kicker {

            font-size: 11px;

            letter-spacing: 3px;

            color: #79e8ff;
        }


        .echo-story-box h2 {

            font-size: 32px;

            margin: 8px 0;
        }


        .echo-story-meta {

            opacity: .55;

            font-size: 13px;

            margin-bottom: 25px;
        }


        .echo-story-box p {

            line-height: 1.9;

            font-size: 16px;

            color:
                rgba(255,255,255,.88);
        }


        .echo-story-actions {

            display: flex;

            gap: 10px;

            margin-top: 25px;
        }


        .echo-story-actions button {

            padding: 11px 18px;

            border-radius: 12px;

            border:
                1px solid
                rgba(255,255,255,.15);

            background:
                rgba(255,255,255,.07);

            color: white;

            cursor: pointer;
        }


        @media(max-width:600px) {

            .echo-date-grid {

                grid-template-columns: 1fr;
            }


            .echo-modal-box {

                padding: 22px;
            }


            .echo-story-box {

                margin: 40px 15px;

                padding: 22px;
            }
        }

    `;


    document.head.appendChild(
        style
    );
}


/* =========================================================
   START APPLICATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "🌌 ECHOES INITIALIZING..."
        );


        addModalStyles();


        setupCategories();


        setupGenerateButton();


        setupLanguage();


        console.log(
            "✨ ECHOES READY"
        );
    }
);